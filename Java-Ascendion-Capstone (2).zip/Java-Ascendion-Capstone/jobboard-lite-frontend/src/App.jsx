import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import LandingPage from './components/LandingPage/LandingPage';
import JobCard from './components/JobCard/JobCard';
import JobApplicationForm from './components/JobApplicationForm/JobApplicationForm';
import Layout from './components/Layout/Layout'; // new layout wrapper
import './App.css';

function App() {
  const router = createBrowserRouter([
    {
      path: '/',
      element: <Layout />,
      children: [
        {
          index: true,
          element: <LandingPage />
        },
        {
          path: 'jobs/:id',
          element: <JobCard />
        },
        {
          path: 'jobs/:id/apply',
          element: <JobApplicationForm />
        }
      ]
    }
  ]);

  return <RouterProvider router={router} />;
}

export default App;
