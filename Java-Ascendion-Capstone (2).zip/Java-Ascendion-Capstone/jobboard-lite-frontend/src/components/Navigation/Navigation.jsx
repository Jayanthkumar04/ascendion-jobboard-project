import React from 'react'
import { Link,useNavigate } from 'react-router-dom'
export default function Navigation() {

const navigate = useNavigate();

function goToHome() {

navigate('/',{replace:true});

}

  return (
    <>
 <nav className="navbar navbar-expand-lg navbar-light bg-light">
  <a className="navbar-brand"  onClick={goToHome}>JobsList</a>
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>
</nav>
    </>
  )
}