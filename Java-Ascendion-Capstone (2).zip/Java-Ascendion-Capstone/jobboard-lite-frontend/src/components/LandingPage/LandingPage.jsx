import React, { useEffect, useState } from 'react';
import JobCard from '../JobCard/JobCard';
import { Link } from 'react-router-dom';
export default function LandingPage() {
  const [jobs, setJobs] = useState([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    fetch('http://localhost:8080/job')
      .then((response) => response.json())
      .then((data) => setJobs(data))
      .catch((error) => console.error("Error fetching jobs:", error));
  }, []);

  function handleSearch() {

    if(search.length === 0){

        fetch(`http://localhost:8080/job`)
        .then((response) => response.json())
        .then((data) => {
          setJobs(data);
          console.log(data);
        })
        .catch((error) => {
          console.error("Error fetching jobs:", error);
          setJobs([]);
        });

    }
    else{
    if (search) {
      fetch(`http://localhost:8080/job/search?search=${search}`)
        .then((response) => response.json())
        .then((data) => {
          setJobs(data);
          console.log(data);
        })
        .catch((error) => {
          console.error("Error fetching jobs:", error);
          setJobs([]);
        });
    }
}
  }

  return (
    <div className="container mt-5">
      <h1 className="mb-3">Welcome to Job Board Lite</h1>
      <p className="lead">Find your next opportunity with us💯</p>
       <p className="lead">
       Your next opportunity is just a click away — discover jobs that match your skills, passion, and goals!
       </p>
      <div className="input-group mb-4">
        <input
          type="text"
          className="form-control"
          placeholder="Search job roles..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <button className="btn btn-success mx-2" onClick={handleSearch} >
          Search
        </button>
      </div>

      {jobs.length === 0 ? (
        <div className="alert alert-warning" role="alert">
          No jobs found.
        </div>
      ) : (
        <div className="row ">
          {jobs.map((job) => (
            
            <div className="col-md-6 mb-4" key={job.id}>
              <div className="card h-100">
                <div className="card-body bg-light">
                  <h5 className="card-title">{job.title}</h5>
                  <h6 className="card-subtitle mb-2 text-muted">
                    {job.company} — {job.location}
                  </h6>
                  <p className="card-text">
                    <strong>Salary:</strong> {job.salaryRange }<br />
                    <strong>Description:</strong> {job.description.substring(0, 100)}
                  </p>
                  <Link to={`/jobs/${job.id}`} className="btn btn-outline-primary mx-2">
                    View Details
                  </Link>
                </div>
              </div>
            </div>
        
          ))}
        </div>
      )}
    </div>
  );
}
