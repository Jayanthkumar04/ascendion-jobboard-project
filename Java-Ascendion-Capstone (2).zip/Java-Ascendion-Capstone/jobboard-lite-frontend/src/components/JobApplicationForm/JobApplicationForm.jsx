
import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';


export default function JobApplicationForm() {

    const { id } = useParams();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [duplicateSubmission, setDuplicateSubmission] = useState(false);
  const navigate =useNavigate();
  const handleSubmit = (e)=>{
    
    e.preventDefault();
  
  
  const application = {

    job:{
        id:id
    },
    fullName,
    email


  };

  fetch('http://localhost:8080/application',{

    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify(application),
  })

  .then((response) => {
    if (response.status === 200 || response.ok) {
      setSubmitted(true);
      setDuplicateSubmission(false);
    } else if (response.status === 409) {
      setDuplicateSubmission(true);
    } else {
      throw new Error('Failed to submit application');
    }
  })
  .catch((error) => {
    console.error('Application submission error:', error);
  });
};

function goToHome()
{
navigate('/',{replace:true})
}

if (submitted) {
    return (
      <div className="container mt-5">
        <div className="alert alert-success">Application submitted successfully! we will get back to you soon</div>
        <button className="btn btn-primary" onClick={goToHome} >Explore more jobs</button>
      </div>
    );
  }
  return (
    <div className="container mt-5">
      <h2>Apply for Job ID: {id}</h2>

      {duplicateSubmission && (
        <div className="alert alert-warning">
          You have already submitted an application for this job. Please explore other jobs.
        </div>
      )}

      <form onSubmit={handleSubmit} className="mt-4">
        <div className="mb-3">
          <label className="form-label">Full Name</label>
          <input
            type="text"
            className="form-control"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Email Address</label>
          <input
            type="email"
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-success">
          Submit Application
        </button>
      </form>
    </div>
    
  );
}