import React, { useEffect, useState } from 'react'
import { useParams,useNavigate, Navigate } from 'react-router-dom'
import { Link } from 'react-router-dom';
export default function JobCard() {

   const {id} = useParams(); 

   const[job,setJob] = useState(null);

   const navigate = useNavigate();
   
   useEffect(()=>{

    fetch(`http://localhost:8080/job/${id}`)
      .then(res => res.json())
      .then(data => setJob(data))
      .catch(err => console.error("Error fetching job details", err));

   },[id]);
   if (!job) return <p className="text-center mt-5">Loading job details...</p>;
   
   function handleApplyClick()
   {
    console.log("yes i am inn")
  navigate(`/jobs/${id}/apply`, { replace: true });
   }

return (
<>
<div className="container mt-5">
      <div className="card shadow-lg">
        <div className="card-body">
          <h2 className="card-title">{job.title}</h2>
          <h5 className="card-subtitle mb-3 text-muted">{job.company} — {job.location}</h5>

          <p className="card-text"><strong>Salary:</strong> {job.salaryRange || 'Not specified'}</p>
          <p className="card-text"><strong>Description:</strong><br /> {job.description}</p>
          <p className="card-text">
            <strong>Required Skills:</strong> { job.requiredSkills}
          </p>

          <button className="btn btn-primary mt-3" onClick={handleApplyClick}>
            Apply Now
          </button>
        
        </div>
      </div>
    </div>
</>  
)
}
