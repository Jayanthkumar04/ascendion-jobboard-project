package com.jobboard.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobboard.dvo.Application;
import com.jobboard.exceptions.ApplicationAlreadyExistsException;
import com.jobboard.exceptions.EntityNotFoundException;
import com.jobboard.repo.ApplicationRepo;
import com.jobboard.repo.JobRepo;

@Service
public class ApplicationServiceImpl implements ApplicationService{

	@Autowired
	private ApplicationRepo repo;
	
	@Autowired
	private JobRepo jobRepo;
	
	@Override
	public Application addApplication(Application application) {

		if(jobRepo.findById(application.getJob().getId()).isPresent())
		{	Optional<Application> existingApp = repo.findByfullNameAndEmailAndJobId(
		        application.getFullName(), 
		        application.getEmail(), 
		        application.getJob().getId()
		    );

		
		    if (existingApp.isPresent()) {
		        throw new ApplicationAlreadyExistsException("Application already exists for this job.");
		    }

		    return repo.save(application);	
		    
		}

		
		else {
			throw new EntityNotFoundException("the job with id "+application.getJob().getId()+" is not found");
			
			}
}
	@Override
	public List<Application> getAllApplications() {
		return repo.findAll();
	}

	
}
