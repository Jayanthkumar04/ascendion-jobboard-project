package com.jobboard.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jobboard.dvo.Application;

@Repository
public interface ApplicationRepo extends JpaRepository<Application, Long>{

	public Optional<String> findByEmail(String email);
	
	public Optional<String> findByfullName(String name);
	
	public Optional<Application> findByfullNameAndEmailAndJobId(String fullName,String Email,Long jobId); 
}
