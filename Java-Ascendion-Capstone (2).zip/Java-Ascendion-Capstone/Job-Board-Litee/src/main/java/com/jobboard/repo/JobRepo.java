package com.jobboard.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jobboard.dvo.Job;

@Repository
public interface JobRepo extends JpaRepository<Job, Long>{

	
	List<Job> findByTitle(String title);
	
	List<Job> findByLocation(String location);
	
}
