package com.jobboard.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobboard.dvo.Job;
import com.jobboard.exceptions.EntityNotFoundException;
import com.jobboard.repo.JobRepo;

@Service
public class JobServiceImpl implements JobService {

	@Autowired
	private JobRepo repo;

	@Override
	public List<Job> getAllJobs() {

		return repo.findAll();

	}

	@Override
	public Job getJobById(Long id) {

		Optional<Job> job = repo.findById(id);

		if (job.isPresent()) {
			return job.get();
		} else {
			throw new EntityNotFoundException("job id with " + id + " is not found");
		}

	}

	@Override
	public List<Job> getJobsBySearch(String search) {

		List<Job> jobs = repo.findByTitle(search);

		System.out.println(jobs);
		if (jobs != null) {
			return jobs;
		} else {
			throw new EntityNotFoundException("Job with title " + search + " is not found");
		}

	}

	@Override
	public List<Job> getJobsByLocation(String location) {

		List<Job> jobs = repo.findByLocation(location);

		System.out.println(jobs);
		if (jobs != null) {
			return jobs;
		} else {
			throw new EntityNotFoundException("Job in location " + location + " is not found");
		}

	}

	@Override
	public Job addJob(Job job) {

		return repo.save(job);
	}

}
