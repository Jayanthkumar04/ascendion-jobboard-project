package com.jobboard.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jobboard.dvo.Job;
import com.jobboard.service.JobService;

@RestController
@RequestMapping("/job")
@CrossOrigin(origins = "http://localhost:5173")
public class JobController {

	@Autowired
	private JobService service;
	
   @GetMapping
   public List<Job> getAllJobs()
   {
	   return service.getAllJobs();
   }
	
   @GetMapping("{id}")
   public Job getJobById(@PathVariable("id") Long id)
   {
	   return service.getJobById(id);
   }
   
   @GetMapping("search")
   public List<Job> getJobsBySearch(@RequestParam("search") String search)
   {
	   return service.getJobsBySearch(search);
   }
   @GetMapping("location")
   public List<Job> getJobsByLocation(@RequestParam("location") String location)
   {
	   return service.getJobsByLocation(location);
   }
   
   @PostMapping
   public Job addJob(@RequestBody Job job)
   {
	
	   
	   return service.addJob(job);
   
   }
   
   
   
   
   
}
