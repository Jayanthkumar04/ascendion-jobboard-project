package com.jobboard.dvo;

import org.hibernate.annotations.ManyToAny;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Application {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String fullName;
	
	private String email;
	
	
	@ManyToOne
	@JoinColumn(name="job_id",nullable=false)
	@JsonBackReference
	private Job job;


	public Application() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Application(Long id, String fullName, String email, Job job) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.email = email;
		this.job = job;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getFullName() {
		return fullName;
	}


	public void setFullName(String fullName) {
		this.fullName = fullName;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Job getJob() {
		return job;
	}


	public void setJob(Job job) {
		this.job = job;
	}


	@Override
	public String toString() {
		return "Application [id=" + id + ", fullName=" + fullName + ", email=" + email + ", job=" + job + "]";
	}
	
	
	

}
