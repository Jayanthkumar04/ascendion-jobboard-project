package com.jobboard.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.jobboard.dvo.Job;

public interface JobService {

	public List<Job> getAllJobs();
	
	public Job getJobById(Long id);
	
	public List<Job> getJobsBySearch(String search);
	
	public List<Job> getJobsByLocation(String location);
	
	public Job addJob(@RequestBody Job job);
}
