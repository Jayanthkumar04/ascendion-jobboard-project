package com.jobboard.service;

import java.util.List;

import com.jobboard.dvo.Application;

public interface ApplicationService {

	public Application addApplication(Application application);

	public List<Application> getAllApplications();
}
