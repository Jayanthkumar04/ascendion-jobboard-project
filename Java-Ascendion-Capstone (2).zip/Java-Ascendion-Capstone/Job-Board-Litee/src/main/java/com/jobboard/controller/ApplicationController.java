package com.jobboard.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jobboard.dvo.Application;
import com.jobboard.service.ApplicationService;
import com.jobboard.service.JobService;

@RestController
@RequestMapping("/application")
@CrossOrigin(origins = "http://localhost:5173")
public class ApplicationController {

	@Autowired
	private ApplicationService service;
	
	@PostMapping
	public Application addApplication(@RequestBody Application application)
	{
		
		
		return service.addApplication(application);
	}
	
	@GetMapping
	public List<Application> getAllApplications()
	{
		return service.getAllApplications();
	}
	
}
